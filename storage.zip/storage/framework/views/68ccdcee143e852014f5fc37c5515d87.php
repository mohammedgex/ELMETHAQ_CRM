<?php $__env->startSection('title', 'تعريف المستندات'); ?>

<?php $__env->startSection('content_header'); ?>
    <h3>مرفقات - <?php echo e($client->name_ar); ?> </h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<button class="print-btn" onclick="window.print()">طباعة المرفقات</button>

        <?php $__currentLoopData = $client->documentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documentType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="page">
            <h3><?php echo e($documentType->document_type ?? 'مرفق'); ?></h3>
            <img src="<?php echo e(asset('storage/' . $documentType->file)); ?>" alt="<?php echo e($documentType->document_type ?? 'مرفق'); ?>">
            <div class="footer my-2">
                <div class="footer d-flex justify-content-between" style="font-size: 12px;">
                    <span>التاريخ: <?php echo e(now()->format('Y-m-d')); ?></span>
                    <span>الساعة: <?php echo e(now()->format('H:i')); ?></span>
                    <span>اسم الموظف: <?php echo e(auth()->user()->name ?? '---'); ?></span>
                </div>
            </div>
            <hr>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
        body {
            font-family: 'Cairo';
            margin: 0;
            padding: 0;
        }

        

        .page {
            page-break-after: always;
            padding: 40px;
            text-align: center;
        }

        .page h3 {
            margin-bottom: 20px;
            color: #333;
        }

        .page img {
            width: 600px;
            height: 600px;
            border: 1px solid #ccc;
            border-radius: 10px;
        }

        .print-btn {
            display: block;
            margin: 20px auto;
            padding: 12px 24px;
            background-color: #28a745;
            color: white;
            border: none;
            font-size: 18px;
            border-radius: 6px;
            cursor: pointer;
        }

        .footer {
    font-size: 12px;
    margin-top: 50px;
}

        @media print {
            .print-btn {
                display: none;
            }
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('title', 'تعريف المستندات'); ?>

<?php $__env->startSection('content_header'); ?>
<h3>مرفقات - <?php echo e($client->name_ar); ?> </h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<button class="print-btn" onclick="window.print()">طباعة المرفقات</button>

<div class="page">
    <h3> الصورة الشخصية</h3>
    <img src="<?php echo e(asset('storage/' . $client->image)); ?>" alt="الصورة الشخصية">
    <div class="footer my-2">
        <div class="footer d-flex justify-content-between" style="font-size: 12px;">
            <span>التاريخ: <?php echo e(now()->format('Y-m-d')); ?></span>
            <span>الساعة: <?php echo e(now()->format('H:i')); ?></span>
            <span>اسم الموظف: <?php echo e(auth()->user()->name ?? '---'); ?></span>
        </div>
    </div>
    <hr>
</div>

<div class="page">
    <h3>  جواز السفر</h3>
    <img src="<?php echo e(asset('storage/' . $client->mrz_image)); ?>" alt="الصورة الشخصية">
    <div class="footer my-2">
        <div class="footer d-flex justify-content-between" style="font-size: 12px;">
            <span>التاريخ: <?php echo e(now()->format('Y-m-d')); ?></span>
            <span>الساعة: <?php echo e(now()->format('H:i')); ?></span>
            <span>اسم الموظف: <?php echo e(auth()->user()->name ?? '---'); ?></span>
        </div>
    </div>
    <hr>
</div>

<?php $__currentLoopData = $client->documentTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $documentType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="page">
    <h3><?php echo e($documentType->document_type ?? 'مرفق'); ?></h3>
    <img src="<?php echo e(asset('storage/' . $documentType->file)); ?>" alt="<?php echo e($documentType->document_type ?? 'مرفق'); ?>">
    <div class="footer my-2">
        <div class="footer d-flex justify-content-between" style="font-size: 12px;">
            <span>التاريخ: <?php echo e(now()->format('Y-m-d')); ?></span>
            <span>الساعة: <?php echo e(now()->format('H:i')); ?></span>
            <span>اسم الموظف: <?php echo e(auth()->user()->name ?? '---'); ?></span>
        </div>
    </div>
    <hr>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    body {
        font-family: 'Cairo';
        margin: 0;
        padding: 0;
    }



    .page {
        page-break-after: always;
        padding: 40px;
        text-align: center;
    }

    .page h3 {
        margin-bottom: 20px;
        color: #333;
    }

    .page img {
        width: 600px;
        height: 600px;
        border: 1px solid #ccc;
        border-radius: 10px;
    }

    .print-btn {
        display: block;
        margin: 20px auto;
        padding: 12px 24px;
        background-color: #28a745;
        color: white;
        border: none;
        font-size: 18px;
        border-radius: 6px;
        cursor: pointer;
    }

    .footer {
        font-size: 12px;
        margin-top: 50px;
    }

    @media print {
        .print-btn {
            display: none;
        }
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\SHAIMAA\AppData\Roaming\Composer\TestRtlElmethaq\resources\views/print-customer/cutomer-documents.blade.php ENDPATH**/ ?>