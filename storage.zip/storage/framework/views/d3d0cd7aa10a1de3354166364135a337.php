<?php $__env->startSection('title', 'أنواع المستندات'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1 style="font-weight:bold; text-align:right;">ارسال رسائل</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<iframe src="https://bulk.whysms.com" width="100%" height="800px" style="border-radius: 12px;"></iframe>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\SHAIMAA\AppData\Roaming\Composer\TestRtlElmethaq\resources\views/bulk-sms.blade.php ENDPATH**/ ?>