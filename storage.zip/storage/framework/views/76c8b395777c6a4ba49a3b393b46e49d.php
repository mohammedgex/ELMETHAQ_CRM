<?php $__env->startSection('title', 'تعريف المستندات'); ?>

<?php $__env->startSection('content_header'); ?>
    <h3>المهام </h3>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container w-75 bg-white p-4 shadow-lg rounded">
        <h2 class="text-center mb-4 border-bottom pb-3"> قائمة المهام</h2>

        <button class="btn btn-primary w-100 mb-4" data-bs-toggle="modal" data-bs-target="#exampleModal"> اسناد مهمة</button>

        <!-- Modal -->
        <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <form action="<?php echo e(route('user-tasks.create')); ?>" method="POST" class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">اضافة مهمة</h5>
                        <button type="button" class="" data-bs-dismiss="modal" aria-label="Close"><i
                                class="fas fa-times-circle text-danger"></i></button>
                    </div>
                    <div class="modal-body">
                        <?php echo csrf_field(); ?>
                        <label class="font-weight-bold"> الموظف </label>
                        <select class="form-control fw-bold" name="receiving_user_id">
                            <option value="">اختر الموظف</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <label class="font-weight-bold"> وصف المهمة </label>
                        <div class="col-md-12 input-group mb-3">
                            <div class="input-group-prepend">
                                <span class="input-group-text"><i class="fas fa-edit" style="color:#7c6232;"></i></span>
                            </div>
                            <input type="text" class="form-control" name="description" placeholder="أدخل وصف المهمة"
                                required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-secondary">اسناد المهمة</button>
                    </div>
                </form>
            </div>
        </div>


        <div id="taskList" class="d-flex flex-column gap-3">
            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div
                    class="task-item p-4 bg-opacity-25 border  rounded d-flex justify-content-between align-items-center my-2 <?php echo e($task->status == 'done' ? ' bg-success border-success' : ' bg-warning border-warning'); ?>">
                    <div class="w-75">
                        <h4 class="mb-1 text-black border-bottom pb-2" style="color:black;font-weight:700;font-size:28px;">
                            مهمة من الموظف: "<?php echo e($task->sender->name); ?>"</h4>
                        <p class="mb-2" style="font-weight:300;font-size:14px;"> <?php echo e($task->description); ?>.</p>
                        <small class="text-white">📅 <?php echo e($task->created_at->format('Y-m-d')); ?></small>
                    </div>


                    <?php if($task->status == 'new'): ?>
                        <div>
                            <a href="<?php echo e(route('user-tasks.done', $task->id)); ?>"><button
                                    class="btn mt-1 px-2 shadow-sm text-success"
                                    style="background-color: green;font-weight:700"> <i
                                        class="fas fa-check text-white"></i></button></a>
                            <button class="btn mt-1 px-1 shadow-sm text-warning"
                                style="background-color: #ffffff;font-weight:700"><i class="fas fa-history"></i>
                                جديدة</button>
                        </div>
                    <?php elseif($task->status == 'done'): ?>
                        <button class="btn mt-1 px-1 shadow-sm text-success"
                            style="background-color: #ffffff;font-weight:700">
                            <i class="fas fa-check"></i> مكتملة</button>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <style>
        .form-control {
            border-radius: 10px;
            padding: 12px;
            height: 50px;
            border: 1px solid #ced4da;
            transition: all 0.3s ease-in-out;
        }

        .form-control:focus {
            border-color: #997a44;
            /* box-shadow: 0 0 8px rgba(153, 122, 68, 0.3); */
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
    </script>
    <script></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\SHAIMAA\AppData\Roaming\Composer\TestRtlElmethaq\resources\views/tasks/tasks.blade.php ENDPATH**/ ?>